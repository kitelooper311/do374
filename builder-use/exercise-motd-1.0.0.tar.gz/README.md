# Ansible Collection - exercise.motd

Documentation for the collection.
